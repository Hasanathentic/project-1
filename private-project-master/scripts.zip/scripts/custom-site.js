$(document).ready(function () {

    $('.about-list').on('mouseover', 'li', function () {
        $('.about-list>li.active').removeClass('active');
        $(this).addClass('active');
    });
    $('.expand-icon').click(function () {
  
  
    var id = $(this).attr('id');
    id_no = getSecondPart(id);
    if ($('#show-' + id_no).css('display') == 'none') {
        $('#show-' + id_no).css("display", "block");
        $('#q-' + id_no).css('color', '#E26640');

        $(this).css("display", "none")
    }
    else {
        $('#show-' + id_no).css("display", "none");
        $('#q-' + id_no).css('color', '#333333');
        $(this).css("display", "block")
    }
    });

    $('.hide-icon').click(function () {
    var id = $(this).attr('id');
    id_no = getSecondPart(id);
    if ($('#hide-' + id_no).css('display') == 'none') {
        $('#hide-' + id_no).css("display", "block");
        $('#q-' + id_no).css('color', '#333333');
        $(this).css("display", "none")
    }
    else {
        $('#hide-' + id_no).css("display", "none");

        $('#q-' + id_no).css('color', '#E26640');
        $(this).css("display", "block")
    }
    });

    //  Active class on click
      $('.navbar-nav .nav-link').click(function () {
        $('.navbar-nav .nav-link').removeClass('active');
        $(this).addClass('active');
      });
  
      // Main Navigation menu active class
      $('.navbar-nav .nav-link').click(function () {
        $('.navbar-nav .nav-link').removeClass('active');
        $(this).addClass('active');
      });
  
      // OffCanvas script for sidebar for login screen
      $('[data-toggle="offcanvas"]').on('click', function () {
        $('.offcanvas-collapse').toggleClass('open');
        document.getElementById("overlay").style.display = "block";
      });
  
      $('.offcanvas-collapse .close').click(function () {
        $('.offcanvas-collapse').toggleClass('open');
        document.getElementById("overlay").style.display = "none";
      });
  
      // Change hambuger menu when open in small screens
      $('#ChangeToggle').click(function () {
        $('#navbar-hamburger').toggleClass('hidden');
        $('#navbar-close').toggleClass('hidden');
      });
  
      // Counter (+/-) increment/decrement control
      $('.minus').click(function () {
        var $input = $(this).parent().find('input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();
        return false;
      });
      $('.plus').click(function () {
        var $input = $(this).parent().find('input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();
        return false;
      });
  
    

});